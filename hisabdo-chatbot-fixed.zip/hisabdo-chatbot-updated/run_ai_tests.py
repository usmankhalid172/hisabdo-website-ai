"""
AI Response Testing - test runner.

Runs a structured test-query dataset through the actual chatbot
components (language detection + intent detection) and records
results, so the quality report is based on genuine output, not
assumptions.

Note: Ollama itself isn't running in this environment, so this
tests the parts of the pipeline that can run standalone -
language detection, Roman Urdu normalization, and intent
detection/entity extraction - which is where most real failures
happen anyway (a wrong intent means a wrong answer regardless of
what the LLM does afterward).
"""

import sys
sys.path.insert(0, "/home/claude/hisabdo-chatbot")

from app.core.language_utils import detect_language, normalize_roman_urdu
from app.orchestrator.intent_detection import detect_intent

# Structured test-query dataset covering every category in the task
TEST_CASES = [
    # -- Product-related questions --
    {"category": "Product", "query": "What is HisabDo?", "expected_intent": "FAQ_QUERY", "expected_lang": "english"},
    {"category": "Product", "query": "Who is HisabDo designed for?", "expected_intent": "UNKNOWN", "expected_lang": "english"},
    {"category": "Product", "query": "HisabDo kya hai?", "expected_intent": "UNKNOWN", "expected_lang": "roman-urdu"},

    # -- FAQ and feature questions --
    {"category": "FAQ/Feature", "query": "How does backup work?", "expected_intent": "BACKUP_HELP", "expected_lang": "english"},
    {"category": "FAQ/Feature", "query": "How can I export a PDF report?", "expected_intent": "REPORT_HELP", "expected_lang": "english"},
    {"category": "FAQ/Feature", "query": "How do I add a customer?", "expected_intent": "FEATURE_GUIDANCE", "expected_lang": "english"},
    {"category": "FAQ/Feature", "query": "Does HisabDo support voice entry?", "expected_intent": "UNKNOWN", "expected_lang": "english"},

    # -- Help / support questions --
    {"category": "Help/Support", "query": "I need help restoring my backup", "expected_intent": "BACKUP_HELP", "expected_lang": "english"},
    {"category": "Help/Support", "query": "Something is wrong, who do I contact?", "expected_intent": "UNKNOWN", "expected_lang": "english"},

    # -- English queries (financial) --
    {"category": "English", "query": "How much does Ahmed owe me?", "expected_intent": "CUSTOMER_BALANCE_QUERY", "expected_lang": "english"},
    {"category": "English", "query": "What were my expenses this month?", "expected_intent": "EXPENSE_QUERY", "expected_lang": "english"},
    {"category": "English", "query": "What is my total receivable amount?", "expected_intent": "RECEIVABLE_QUERY", "expected_lang": "english"},

    # -- Urdu / Roman Urdu queries --
    {"category": "Roman Urdu", "query": "Ali ka kitna udhaar hai?", "expected_intent": "CUSTOMER_BALANCE_QUERY", "expected_lang": "roman-urdu"},
    {"category": "Roman Urdu", "query": "Mera kharcha kitna hua is mahine?", "expected_intent": "EXPENSE_QUERY", "expected_lang": "roman-urdu"},
    {"category": "Roman Urdu", "query": "Ali ka kitnaaa udhaar hai?", "expected_intent": "CUSTOMER_BALANCE_QUERY", "expected_lang": "roman-urdu"},
    {"category": "Roman Urdu", "query": "Backup kaise hota hai?", "expected_intent": "BACKUP_HELP", "expected_lang": "roman-urdu"},
    {"category": "Roman Urdu", "query": "علی کے پاس میرا کتنا بقایا ہے؟", "expected_intent": "CUSTOMER_BALANCE_QUERY", "expected_lang": "urdu"},

    # -- Ambiguous / incomplete queries --
    {"category": "Ambiguous", "query": "kitna?", "expected_intent": "UNKNOWN", "expected_lang": "roman-urdu"},
    {"category": "Ambiguous", "query": "balance", "expected_intent": "CUSTOMER_BALANCE_QUERY", "expected_lang": "english"},
    {"category": "Ambiguous", "query": "uski kitna hai", "expected_intent": "UNKNOWN", "expected_lang": "roman-urdu"},

    # -- Unknown / out-of-scope questions --
    {"category": "Out-of-scope", "query": "What's the weather today?", "expected_intent": "UNKNOWN", "expected_lang": "english"},
    {"category": "Out-of-scope", "query": "Tell me a joke", "expected_intent": "UNKNOWN", "expected_lang": "english"},
    {"category": "Out-of-scope", "query": "Can you delete Ali's account?", "expected_intent": "UNKNOWN", "expected_lang": "english"},
]


def run_tests():
    results = []
    for case in TEST_CASES:
        query = case["query"]
        lang = detect_language(query)
        normalized = normalize_roman_urdu(query) if lang == "roman-urdu" else query
        intent_result = detect_intent(normalized)

        lang_pass = lang == case["expected_lang"]
        intent_pass = intent_result.intent == case["expected_intent"]

        results.append({
            **case,
            "detected_lang": lang,
            "detected_intent": intent_result.intent,
            "entity": intent_result.entity,
            "lang_pass": lang_pass,
            "intent_pass": intent_pass,
        })
    return results


if __name__ == "__main__":
    results = run_tests()
    total = len(results)
    lang_correct = sum(1 for r in results if r["lang_pass"])
    intent_correct = sum(1 for r in results if r["intent_pass"])

    print(f"{'Category':<15} {'Query':<40} {'Lang':<12} {'Intent':<25} {'L-OK':<5} {'I-OK':<5}")
    print("-" * 110)
    for r in results:
        print(f"{r['category']:<15} {r['query'][:38]:<40} {r['detected_lang']:<12} {r['detected_intent']:<25} {'YES' if r['lang_pass'] else 'NO':<5} {'YES' if r['intent_pass'] else 'NO':<5}")

    print("\n--- Summary ---")
    print(f"Total test cases: {total}")
    print(f"Language detection accuracy: {lang_correct}/{total} ({lang_correct/total*100:.1f}%)")
    print(f"Intent detection accuracy: {intent_correct}/{total} ({intent_correct/total*100:.1f}%)")

    print("\n--- Failed cases ---")
    for r in results:
        if not r["lang_pass"] or not r["intent_pass"]:
            print(f"- [{r['category']}] \"{r['query']}\" -> lang={r['detected_lang']} (expected {r['expected_lang']}), intent={r['detected_intent']} (expected {r['expected_intent']})")

    import json
    with open("/home/claude/chatbot-concepts/test_results.json", "w") as f:
        json.dump(results, f, indent=2, ensure_ascii=False)
