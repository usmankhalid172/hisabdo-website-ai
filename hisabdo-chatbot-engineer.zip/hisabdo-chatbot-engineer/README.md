# HisabDo AI Chatbot Service — Chatbot Engineer Module

This covers the tasks assigned under **Omesha — AI Chatbot Engineer** in the
HisabDo AI Copilot architecture:

- Chat UI/API integration
- Ollama integration
- Prompt engineering
- Conversation handling
- Intent detection
- Chatbot response system

## What's implemented

| Task | File | Notes |
|---|---|---|
| Chat API | `app/api/chat.py` | `POST /api/ai/chat`, `POST /api/ai/feedback`, `GET /api/ai/health` — matches the API contract in the architecture doc (section 12). |
| Ollama integration | `app/orchestrator/ollama_client.py` | Async client for a local Ollama server's `/api/chat` endpoint. Model/host configurable via env vars. |
| Prompt engineering | `app/orchestrator/prompts.py` | System prompt enforces the anti-hallucination rule (section 23) — the LLM only explains verified data, never invents numbers. |
| Conversation handling | `app/orchestrator/conversation_memory.py` | Bounded, TTL'd in-memory store per `conversationId`; tracks recent turns, detected language, and last-mentioned customer (for pronoun follow-ups like "uski last transaction?"). |
| Intent detection | `app/orchestrator/intent_detection.py` | Rule/keyword-based classifier covering all intents from section 8, plus simple entity extraction (customer name). |
| Chatbot response system | `app/orchestrator/chatbot_service.py` | Ties everything together: language detect → normalize → intent → memory → prompt → Ollama → structured response. |
| Multilingual handling | `app/core/language_utils.py` | Detects English / Urdu / Hindi / Arabic / Roman Urdu, and normalizes common Roman Urdu spelling variants (`kitna`/`kitnay`/`kitnaaa` → `kitna`). |
| Test UI | `static/chat.html` | Minimal chat widget to demo the API without needing the full React frontend. |

## How it fits the bigger architecture

This module intentionally does **not** touch the database or compute any
financial numbers — that stays with the Financial AI module. It calls a
single pluggable hook, `financial_data_provider`, in `chatbot_service.py`.
Right now it returns `None` (so the LLM is explicitly told "no verified
data" instead of guessing). Once the Financial AI teammate's balance/expense
API is ready, it plugs in with one line:

```python
from app.orchestrator.chatbot_service import ChatbotService
from my_financial_module import get_financial_data

chatbot_service = ChatbotService(financial_data_provider=get_financial_data)
```

This keeps the two modules independently testable, matching the
"separate deterministic calculation from generative AI" principle in
section 1 of the architecture doc.

## Running locally

1. Install Ollama and pull a model (e.g. `ollama pull llama3.2`).
2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
3. Start the service:
   ```bash
   uvicorn app.main:app --reload --port 8000
   ```
4. Test:
   ```bash
   curl -X POST http://localhost:8000/api/ai/chat \
     -H "Content-Type: application/json" \
     -d '{"message": "Ali ka kitna udhaar hai?"}'
   ```
5. Or open `static/chat.html` in a browser for a visual test.

## Example request/response

Request:
```json
{ "message": "How do I export a report?" }
```

Response:
```json
{
  "success": true,
  "requestId": "…",
  "conversationId": "…",
  "type": "chat_answer",
  "language": "english",
  "intent": "REPORT_HELP",
  "message": "You can export a report from the Reports section — pick a date range and tap Export as PDF.",
  "data": null,
  "source": { "type": "chat_response" },
  "timestamp": "2026-08-20T00:00:00Z"
}
```

## What's next (handoff points for other modules)

- Wire `financial_data_provider` to the real Financial AI service once available.
- Swap `ConversationMemoryStore`'s in-memory dict for Redis/Mongo for production.
- Replace the rule-based intent classifier with a trained model once labeled query data exists (section 31 — Success Metrics: intent detection accuracy).
- Add multilingual test cases (Urdu/Hindi/Arabic) once Nobita's test dataset is ready.
