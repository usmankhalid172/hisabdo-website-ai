"""
Chatbot Response System.

This is the core of the Chatbot Engineer's scope: it wires together
language detection, Roman Urdu normalization, intent detection,
conversation memory, prompt engineering, and the Ollama LLM call into
a single "handle one chat turn" flow - matching the pipeline in
architecture section 6 (AI Request Processing Flow).

Financial data retrieval itself (talking to MongoDB / the balances
API) belongs to the Financial AI module owned by another teammate.
This service calls a small `financial_data_provider` hook so that,
once that module exists, it plugs in without changing this file.
"""

import uuid
from datetime import datetime, timezone
from typing import Callable, Optional

from app.core.language_utils import detect_language, normalize_roman_urdu
from app.orchestrator.intent_detection import detect_intent, IntentResult
from app.orchestrator.conversation_memory import memory_store, ConversationState
from app.orchestrator.prompts import build_system_prompt, build_user_prompt, build_history_messages
from app.orchestrator.ollama_client import ollama_client, OllamaError
from app.core.models import ChatResponse, ChatSource

# Intents that need verified data from the Financial AI module before answering.
FINANCIAL_INTENTS = {
    "CUSTOMER_BALANCE_QUERY",
    "TRANSACTION_QUERY",
    "EXPENSE_QUERY",
    "RECEIVABLE_QUERY",
    "PAYABLE_QUERY",
}

# Type hint for the pluggable financial-data lookup function
FinancialDataProvider = Callable[[str, Optional[str]], Optional[dict]]


def _default_financial_data_provider(intent: str, entity: Optional[str]) -> Optional[dict]:
    """
    Placeholder until the Financial AI module (teammate-owned) is wired in.
    Returns None so the LLM is told explicitly "no verified data yet"
    instead of ever guessing a number - per the anti-hallucination rule.
    """
    return None


class ChatbotService:
    def __init__(self, financial_data_provider: FinancialDataProvider = None):
        self.financial_data_provider = financial_data_provider or _default_financial_data_provider

    async def handle_message(
        self,
        raw_message: str,
        conversation_id: Optional[str] = None,
        language_hint: Optional[str] = None,
    ) -> ChatResponse:
        request_id = str(uuid.uuid4())

        # 1. Language detection
        language = language_hint or detect_language(raw_message)

        # 2. Roman Urdu normalization (only affects roman-urdu text)
        normalized = normalize_roman_urdu(raw_message) if language == "roman-urdu" else raw_message

        # 3. Conversation memory
        state = memory_store.get_or_create(conversation_id)
        memory_store.set_language(state, language)

        # 4. Intent detection
        intent_result: IntentResult = detect_intent(normalized)

        # resolve pronouns like "uski" using last known entity if this turn has none
        entity = intent_result.entity or (
            state.last_entity if intent_result.intent in FINANCIAL_INTENTS else None
        )
        memory_store.set_entity(state, intent_result.entity)

        # 5. Fetch verified data only for financial intents (never invented by the LLM)
        verified_data = None
        if intent_result.intent in FINANCIAL_INTENTS:
            verified_data = self.financial_data_provider(intent_result.intent, entity)

        # 6. Prompt engineering
        system_prompt = build_system_prompt(language)
        user_prompt = build_user_prompt(normalized, verified_data, intent_result.intent)
        history_messages = build_history_messages(state.turns)

        # 7. LLM call
        try:
            reply_text = await ollama_client.chat(system_prompt, history_messages, user_prompt)
        except OllamaError:
            reply_text = self._fallback_reply(language)

        # 8. Update memory
        memory_store.add_turn(state, "user", raw_message)
        memory_store.add_turn(state, "assistant", reply_text)

        return ChatResponse(
            success=True,
            requestId=request_id,
            conversationId=state.conversation_id,
            type="financial_answer" if intent_result.intent in FINANCIAL_INTENTS else "chat_answer",
            language=language,
            intent=intent_result.intent,
            message=reply_text,
            data=verified_data,
            source=ChatSource(type="verified_financial_data" if verified_data else "chat_response"),
            timestamp=datetime.now(timezone.utc).isoformat(),
        )

    @staticmethod
    def _fallback_reply(language: str) -> str:
        fallback_by_language = {
            "roman-urdu": "Mujhe is waqt jawab dene mein masla ho raha hai, thori dair mein dobara koshish karein.",
            "urdu": "معذرت، اس وقت جواب دینے میں مسئلہ ہو رہا ہے، براہ کرم دوبارہ کوشش کریں۔",
            "hindi": "अभी जवाब देने में समस्या हो रही है, कृपया थोड़ी देर बाद फिर कोशिश करें।",
            "arabic": "عذرًا، أواجه مشكلة في الرد الآن، يرجى المحاولة مرة أخرى.",
            "english": "I'm having trouble responding right now, please try again shortly.",
        }
        return fallback_by_language.get(language, fallback_by_language["english"])


chatbot_service = ChatbotService()
