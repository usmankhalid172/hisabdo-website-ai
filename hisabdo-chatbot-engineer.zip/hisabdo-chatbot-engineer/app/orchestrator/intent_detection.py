"""
Intent Detection module.

Per architecture section 8 (Intent Categories), the chatbot must
classify every incoming message into one of a fixed set of intents
before deciding how to respond. This is a rule/keyword-based
classifier for the prototype phase - fast, offline, and free to run,
matching the doc's "cost-optimized, offline-first" principle.

Design note: this module ONLY classifies intent + pulls out a simple
entity (e.g. a customer name). It never talks to the database - that
stays the Financial AI module's job (owned by another teammate), which
keeps this component safe to hand off independently.
"""

import re
from dataclasses import dataclass
from typing import Optional

INTENTS = [
    "PRODUCT_INFORMATION",
    "FAQ_QUERY",
    "FEATURE_GUIDANCE",
    "CUSTOMER_BALANCE_QUERY",
    "TRANSACTION_QUERY",
    "EXPENSE_QUERY",
    "RECEIVABLE_QUERY",
    "PAYABLE_QUERY",
    "BUSINESS_INSIGHT",
    "ANALYTICS_QUERY",
    "RECOMMENDATION_QUERY",
    "REPORT_HELP",
    "BACKUP_HELP",
    "LANGUAGE_SUPPORT",
    "GENERAL_CONVERSATION",
    "UNKNOWN",
]

# Keyword sets per intent, covering English + Roman Urdu + a few Urdu-script terms.
INTENT_KEYWORDS = {
    "CUSTOMER_BALANCE_QUERY": [
        "owe", "owes", "balance", "udhaar", "udhar", "baqaya", "reh raha",
        "kitna paisa", "بقایا",
    ],
    "TRANSACTION_QUERY": [
        "transaction", "last transaction", "history", "record", "lena dena",
    ],
    "EXPENSE_QUERY": [
        "expense", "expenses", "kharcha", "kharche", "spending", "spent",
    ],
    "RECEIVABLE_QUERY": [
        "receivable", "receivables", "wasooli", "milna hai", "total receivable",
    ],
    "PAYABLE_QUERY": [
        "payable", "payables", "dena hai", "i owe",
    ],
    "BUSINESS_INSIGHT": [
        "insight", "trend", "increase", "decrease", "pattern", "compare",
    ],
    "ANALYTICS_QUERY": [
        "analytics", "report data", "statistics", "stats",
    ],
    "RECOMMENDATION_QUERY": [
        "recommend", "suggestion", "suggest", "what should i do",
    ],
    "REPORT_HELP": [
        "pdf", "export", "report", "generate report",
    ],
    "BACKUP_HELP": [
        "backup", "restore", "backup restore",
    ],
    "FEATURE_GUIDANCE": [
        "how do i", "how can i", "how to", "kaise", "kesy karen",
        "add customer", "record transaction",
    ],
    "FAQ_QUERY": [
        "what is hisabdo", "faq", "help", "guide",
    ],
    "PRODUCT_INFORMATION": [
        "what is hisabdo", "about hisabdo", "hisabdo kya hai",
    ],
    "LANGUAGE_SUPPORT": [
        "which languages", "language support", "zubaan",
    ],
    "GENERAL_CONVERSATION": [
        "hello", "hi", "salam", "assalam", "thanks", "shukriya", "ok", "bye",
    ],
}

# Very simple name-entity pattern: capitalized word after "does/ka/ki"
ENTITY_PATTERNS = [
    r"does\s+([A-Za-z]+)\s+owe",
    r"([A-Za-z]+)\s+ka\s+(?:kitna|udhaar|balance)",
    r"([A-Za-z]+)\s+owes",
]


@dataclass
class IntentResult:
    intent: str
    entity: Optional[str] = None
    confidence: float = 0.0


def detect_intent(normalized_text: str) -> IntentResult:
    """
    Classify normalized user text into one of INTENTS.

    Scoring: count keyword hits per intent, pick the highest. Ties go
    to the earlier-declared (higher-priority) intent, so financial
    intents are checked before general ones.
    """
    text = normalized_text.lower()
    best_intent = "UNKNOWN"
    best_score = 0

    for intent, keywords in INTENT_KEYWORDS.items():
        score = sum(1 for kw in keywords if kw in text)
        if score > best_score:
            best_score = score
            best_intent = intent

    entity = _extract_entity(text)

    confidence = min(1.0, 0.4 + 0.2 * best_score) if best_score > 0 else 0.2
    return IntentResult(intent=best_intent, entity=entity, confidence=confidence)


def _extract_entity(text: str) -> Optional[str]:
    for pattern in ENTITY_PATTERNS:
        match = re.search(pattern, text, re.IGNORECASE)
        if match:
            return match.group(1).capitalize()
    return None
