"""
Conversation memory handling.

Per architecture section 25 (Conversation Memory), the system should
support controlled, bounded memory: recent turns, user language, and
the "selected customer" context (so "uski last transaction?" resolves
"uski" = the customer mentioned earlier) - without keeping sensitive
financial data around longer than needed.

This is an in-memory store for the prototype. In production this would
move to Redis / Mongo with the same interface, so swapping storage
later does not touch the orchestrator code.
"""

import time
import uuid
from dataclasses import dataclass, field
from typing import Dict, List, Optional

from app.core.config import settings


@dataclass
class Turn:
    role: str          # "user" or "assistant"
    text: str
    timestamp: float = field(default_factory=time.time)


@dataclass
class ConversationState:
    conversation_id: str
    language: Optional[str] = None
    last_entity: Optional[str] = None       # e.g. last customer name mentioned
    turns: List[Turn] = field(default_factory=list)
    updated_at: float = field(default_factory=time.time)


class ConversationMemoryStore:
    """Simple TTL'd in-memory conversation store, keyed by conversation id."""

    def __init__(self) -> None:
        self._store: Dict[str, ConversationState] = {}

    def get_or_create(self, conversation_id: Optional[str]) -> ConversationState:
        self._evict_expired()

        if conversation_id and conversation_id in self._store:
            return self._store[conversation_id]

        new_id = conversation_id or str(uuid.uuid4())
        state = ConversationState(conversation_id=new_id)
        self._store[new_id] = state
        return state

    def add_turn(self, state: ConversationState, role: str, text: str) -> None:
        state.turns.append(Turn(role=role, text=text))
        # keep only the most recent N turns to bound memory + prompt size
        state.turns = state.turns[-settings.MAX_HISTORY_TURNS:]
        state.updated_at = time.time()

    def set_entity(self, state: ConversationState, entity: Optional[str]) -> None:
        if entity:
            state.last_entity = entity

    def set_language(self, state: ConversationState, language: str) -> None:
        state.language = language

    def _evict_expired(self) -> None:
        now = time.time()
        expired = [
            cid for cid, state in self._store.items()
            if now - state.updated_at > settings.MEMORY_TTL_SECONDS
        ]
        for cid in expired:
            del self._store[cid]


# Single shared instance used by the API layer
memory_store = ConversationMemoryStore()
