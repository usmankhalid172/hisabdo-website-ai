"""
Ollama integration.

Talks to a locally running Ollama instance (per architecture section 19
- Recommended Free Technology Stack: local LLM via Ollama). Kept as a
thin, isolated client so the model or host can change without touching
orchestrator/business logic.
"""

import httpx
from typing import List, Optional

from app.core.config import settings


class OllamaError(Exception):
    """Raised when the Ollama service is unreachable or returns an error."""


class OllamaClient:
    def __init__(self, host: str = None, model: str = None, timeout: int = None):
        self.host = host or settings.OLLAMA_HOST
        self.model = model or settings.OLLAMA_MODEL
        self.timeout = timeout or settings.OLLAMA_TIMEOUT

    async def chat(self, system_prompt: str, history: List[dict], user_prompt: str) -> str:
        """
        Send a chat-style request to Ollama's /api/chat endpoint and
        return the assistant's reply text.
        """
        messages = [{"role": "system", "content": system_prompt}]
        messages.extend(history)
        messages.append({"role": "user", "content": user_prompt})

        payload = {
            "model": self.model,
            "messages": messages,
            "stream": False,
        }

        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                response = await client.post(f"{self.host}/api/chat", json=payload)
                response.raise_for_status()
                data = response.json()
                return data.get("message", {}).get("content", "").strip()
        except httpx.HTTPError as exc:
            raise OllamaError(f"Failed to reach Ollama at {self.host}: {exc}") from exc

    async def health_check(self) -> bool:
        try:
            async with httpx.AsyncClient(timeout=5) as client:
                response = await client.get(f"{self.host}/api/tags")
                return response.status_code == 200
        except httpx.HTTPError:
            return False


ollama_client = OllamaClient()
