"""
Request / response schemas for the Chatbot Engineer module.

These mirror the API contract defined in the AI Architecture document
(section 12 - Financial API Layer / Chat API), scoped to what the
chatbot engineer owns: chat turns, intent, language, conversation id.
"""

from typing import Optional, Dict, Any
from pydantic import BaseModel, Field


class ChatRequest(BaseModel):
    message: str = Field(..., description="Raw user message, any supported language")
    conversationId: Optional[str] = Field(
        default=None, description="Existing conversation id, if continuing a chat"
    )
    language: Optional[str] = Field(
        default=None,
        description="Optional language hint from client (english, urdu, roman-urdu, hindi, arabic)",
    )


class ChatSource(BaseModel):
    type: str = "chat_response"


class ChatResponse(BaseModel):
    success: bool = True
    requestId: str
    conversationId: str
    type: str
    language: str
    intent: str
    message: str
    data: Optional[Dict[str, Any]] = None
    source: ChatSource = ChatSource()
    timestamp: str


class FeedbackRequest(BaseModel):
    requestId: str
    conversationId: str
    helpful: bool
    reason: Optional[str] = None
