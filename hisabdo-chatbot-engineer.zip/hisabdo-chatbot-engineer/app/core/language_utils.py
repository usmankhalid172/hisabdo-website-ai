"""
Language detection + Roman Urdu spelling normalization.

Per architecture section 13 (Multilingual Architecture), the rule is:
    Input Language = Output Language

Roman Urdu needs special handling because the same word is spelled many
ways ("kitna", "kitnaaa", "kitny", "kitnay"). We normalize common
variants BEFORE intent detection so the intent layer sees a consistent
vocabulary.
"""

import re

# Common Roman Urdu spelling variants -> canonical form
ROMAN_URDU_NORMALIZATION_MAP = {
    r"\bkitn[ae]y*a*\b": "kitna",
    r"\bpais[ae]y*a*\b": "paisa",
    r"\budh[ao]a?r+\b": "udhaar",
    r"\breh\s*rah[ae]\b": "reh raha",
    r"\bbaqi\b": "baqaya",
    r"\bbaki\b": "baqaya",
}

URDU_UNICODE_RANGE = re.compile(r"[\u0600-\u06FF]")
ARABIC_MARKERS = ["السلام", "شكرا", "من فضلك"]

# A tiny lexicon that strongly signals Roman Urdu / Hindi-Urdu (Latin script)
ROMAN_URDU_WORDS = {
    "kitna", "kitnay", "paisa", "paise", "udhaar", "udhar", "hai", "ka",
    "ki", "ke", "mera", "meri", "batao", "chahiye", "kaise", "kesy",
    "krna", "karna", "reh", "raha", "baqi", "baqaya", "ap", "aap",
}


def normalize_roman_urdu(text: str) -> str:
    """Collapse common spelling variants of Roman Urdu words to one canonical form."""
    normalized = text.lower()
    for pattern, replacement in ROMAN_URDU_NORMALIZATION_MAP.items():
        normalized = re.sub(pattern, replacement, normalized)
    return normalized


def detect_language(text: str) -> str:
    """
    Lightweight, dependency-free language detector.

    Returns one of: "urdu", "arabic", "hindi", "roman-urdu", "english"

    This is intentionally rule-based for the prototype phase (per the
    doc's offline-first / cost-optimized principle). It can later be
    swapped for a proper fastText/langdetect model without changing
    the orchestrator's interface.
    """
    if URDU_UNICODE_RANGE.search(text):
        # Distinguish Arabic vs Urdu roughly by common Arabic-only markers
        if any(marker in text for marker in ARABIC_MARKERS):
            return "arabic"
        return "urdu"

    # Devanagari range for Hindi
    if re.search(r"[\u0900-\u097F]", text):
        return "hindi"

    lowered = text.lower()
    words = set(re.findall(r"[a-z]+", lowered))
    roman_hits = words & ROMAN_URDU_WORDS
    if roman_hits:
        return "roman-urdu"

    return "english"
