"""
Core configuration for the HisabDo AI Chatbot Service.

All environment-dependent values live here so the rest of the
codebase never hardcodes hosts, model names, etc.
"""

import os


class Settings:
    # Ollama connection
    OLLAMA_HOST: str = os.getenv("OLLAMA_HOST", "http://localhost:11434")
    OLLAMA_MODEL: str = os.getenv("OLLAMA_MODEL", "llama3.2")
    OLLAMA_TIMEOUT: int = int(os.getenv("OLLAMA_TIMEOUT", "30"))

    # Conversation memory
    MAX_HISTORY_TURNS: int = 6          # how many past turns to keep per conversation
    MEMORY_TTL_SECONDS: int = 60 * 60   # 1 hour, then a conversation is forgotten

    # Service info
    SERVICE_NAME: str = "hisabdo-ai-chatbot"
    SERVICE_VERSION: str = "0.1.0"


settings = Settings()
