"""
HisabDo AI Chatbot Service - entrypoint.

Run with:
    uvicorn app.main:app --reload --port 8000

Then test with:
    curl -X POST http://localhost:8000/api/ai/chat \
      -H "Content-Type: application/json" \
      -d '{"message": "Ali ka kitna udhaar hai?"}'

Or open /static/chat.html in a browser for a simple UI (point it at
this server's URL).
"""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from app.core.config import settings
from app.api.chat import router as chat_router

app = FastAPI(
    title="HisabDo AI Chatbot Service",
    description="Chat UI/API integration, Ollama integration, intent detection, "
                 "conversation handling, and prompt engineering for HisabDo AI Copilot.",
    version=settings.SERVICE_VERSION,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # tighten before production per section 22 - Security Architecture
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(chat_router)
app.mount("/static", StaticFiles(directory="static"), name="static")


@app.get("/")
async def root():
    return {"service": settings.SERVICE_NAME, "version": settings.SERVICE_VERSION, "status": "running"}
