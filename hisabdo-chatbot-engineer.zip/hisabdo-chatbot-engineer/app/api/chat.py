"""
Chat API - Chat UI/API integration layer.

Exposes POST /api/ai/chat per architecture section 12 (Financial API Layer).
This is the single entry point the React Chat UI / voice UI calls.
"""

from fastapi import APIRouter, HTTPException

from app.core.models import ChatRequest, ChatResponse, FeedbackRequest
from app.orchestrator.chatbot_service import chatbot_service
from app.orchestrator.ollama_client import ollama_client

router = APIRouter(prefix="/api/ai", tags=["chatbot"])

# Simple in-memory feedback log for the prototype (section 27 - AI Feedback System)
_feedback_log = []


@router.post("/chat", response_model=ChatResponse)
async def chat(request: ChatRequest) -> ChatResponse:
    if not request.message or not request.message.strip():
        raise HTTPException(status_code=400, detail="message must not be empty")

    return await chatbot_service.handle_message(
        raw_message=request.message,
        conversation_id=request.conversationId,
        language_hint=request.language,
    )


@router.post("/feedback")
async def feedback(request: FeedbackRequest):
    _feedback_log.append(request.dict())
    return {"success": True, "stored": len(_feedback_log)}


@router.get("/health")
async def health():
    ollama_ok = await ollama_client.health_check()
    return {
        "success": True,
        "service": "chatbot",
        "ollama_reachable": ollama_ok,
    }
